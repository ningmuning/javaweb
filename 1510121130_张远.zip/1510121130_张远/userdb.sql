/*
Navicat MySQL Data Transfer

Source Server         : Test
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : userdb

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-11-13 17:47:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_users
-- ----------------------------
DROP TABLE IF EXISTS `tb_users`;
CREATE TABLE `tb_users` (
  `fd_username` varchar(20) NOT NULL COMMENT '用户名',
  `fd_password` varchar(20) NOT NULL COMMENT '密码',
  `fd_pwdrepeat` varchar(20) NOT NULL COMMENT '确认密码',
  `fd_gender` varchar(20) NOT NULL COMMENT '性别',
  `fd_usertype` varchar(20) DEFAULT NULL COMMENT '类型',
  `fd_birthdate` varchar(20) DEFAULT NULL COMMENT '出生日期',
  `fd_email` varchar(20) DEFAULT NULL COMMENT '电子邮箱',
  PRIMARY KEY (`fd_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_users
-- ----------------------------
INSERT INTO `tb_users` VALUES ('zhangyuan', 'zy123456.', 'zy123456.', '男', 'images/man.jpeg', '1996-12-19', '123456@163.com');
INSERT INTO `tb_users` VALUES ('zhounan', 'zn123456.', 'zn123456.', '女', 'images/woman.jpeg', '1997-13-14', '123456@163.com');
